package com.example.demo.documentstorage;

import lombok.*;

@Setter
@Getter
@AllArgsConstructor
@EqualsAndHashCode
@ToString
public class DownloadRequest {

}
