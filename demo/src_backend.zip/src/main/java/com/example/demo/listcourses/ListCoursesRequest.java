package com.example.demo.listcourses;


import lombok.*;

@Setter
@Getter
@AllArgsConstructor
@EqualsAndHashCode
@ToString
public class ListCoursesRequest {
    private String userId;
}
