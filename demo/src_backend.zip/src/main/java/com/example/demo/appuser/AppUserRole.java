package com.example.demo.appuser;

public enum AppUserRole {
    STUDENT,
    ADMIN,
    INSTRUCTOR,
    DEPARTMENT_MANAGER,
}
