package com.example.demo.semester.course;

public enum CourseType {
    ELECTIVE,
    REQUIRED
}
