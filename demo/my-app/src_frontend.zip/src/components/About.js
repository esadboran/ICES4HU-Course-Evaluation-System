import React from 'react';

// isLoggedIn ve userInfo prop'larını al
const About = () => {
    return (
        <div>
            <h2>Hakkımızda</h2>
            <div>
                <p>Hakkımızda</p>
            </div>

        </div>
    );
};

export default About;
